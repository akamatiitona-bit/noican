#include <jni.h>
#include <oboe/Oboe.h>
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstring>
#include <memory>
#include <mutex>
#include <vector>

class Engine : public oboe::AudioStreamDataCallback {
public:
    Engine() : inBuf_(kMaxFrames), scratch_(kMaxFrames) {}

    bool start(int32_t inId, int32_t outId) {
        std::lock_guard<std::mutex> lock(mutex_);
        stopLocked();
        tripped_ = false;
        curGain_ = 0.0f;
        hot_ = 0;

        oboe::AudioStreamBuilder ib;
        ib.setDirection(oboe::Direction::Input)
                ->setDeviceId(inId)
                ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
                ->setSharingMode(oboe::SharingMode::Exclusive)
                ->setFormat(oboe::AudioFormat::Float)
                ->setChannelCount(oboe::ChannelCount::Mono)
                ->setSampleRate(48000)
                ->setSampleRateConversionQuality(oboe::SampleRateConversionQuality::Medium)
                ->setInputPreset(oboe::InputPreset::Unprocessed)
                ->setFormatConversionAllowed(true)
                ->setChannelConversionAllowed(true);
        if (ib.openStream(in_) != oboe::Result::OK) {
            in_.reset();
            return false;
        }

        oboe::AudioStreamBuilder ob;
        ob.setDirection(oboe::Direction::Output)
                ->setDeviceId(outId)
                ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
                ->setSharingMode(oboe::SharingMode::Exclusive)
                ->setFormat(oboe::AudioFormat::Float)
                ->setChannelCount(oboe::ChannelCount::Stereo)
                ->setSampleRate(48000)
                ->setSampleRateConversionQuality(oboe::SampleRateConversionQuality::Medium)
                ->setUsage(oboe::Usage::Media)
                ->setFormatConversionAllowed(true)
                ->setChannelConversionAllowed(true)
                ->setDataCallback(this);
        if (ob.openStream(out_) != oboe::Result::OK) {
            in_->close();
            in_.reset();
            out_.reset();
            return false;
        }
        out_->setBufferSizeInFrames(out_->getFramesPerBurst() * 2);

        if (in_->requestStart() != oboe::Result::OK ||
            out_->requestStart() != oboe::Result::OK) {
            stopLocked();
            return false;
        }
        return true;
    }

    void stop() {
        std::lock_guard<std::mutex> lock(mutex_);
        stopLocked();
    }

    void setGain(float g) { targetGain_.store(std::clamp(g, 0.0f, 1.0f)); }

    float latencyMs() {
        std::lock_guard<std::mutex> lock(mutex_);
        if (!in_ || !out_) return -1.0f;
        auto a = in_->calculateLatencyMillis();
        auto b = out_->calculateLatencyMillis();
        if (!a || !b) return -1.0f;
        return static_cast<float>(a.value() + b.value());
    }

    float takeInPeak() { return inPeak_.exchange(0.0f); }
    float takeOutPeak() { return outPeak_.exchange(0.0f); }
    bool isTripped() { return tripped_.load(); }

    oboe::DataCallbackResult onAudioReady(oboe::AudioStream *stream,
                                          void *audioData,
                                          int32_t numFrames) override {
        float *out = static_cast<float *>(audioData);
        const int ch = stream->getChannelCount();

        if (numFrames > kMaxFrames || tripped_.load() || !in_) {
            std::memset(out, 0, sizeof(float) * numFrames * ch);
            return oboe::DataCallbackResult::Continue;
        }

        int32_t got = 0;
        for (int i = 0; i < 8; i++) {
            auto r = in_->read(scratch_.data(), numFrames, 0);
            if (!r || r.value() <= 0) break;
            int32_t n = r.value();
            std::copy(scratch_.begin(), scratch_.begin() + n, inBuf_.begin());
            got = n;
            if (n < numFrames) break;
        }
        if (got < numFrames) {
            std::fill(inBuf_.begin() + got, inBuf_.begin() + numFrames, 0.0f);
        }

        const float target = targetGain_.load();
        float inPeak = 0.0f, outPeak = 0.0f;

        for (int i = 0; i < numFrames; i++) {
            curGain_ += (target - curGain_) * 0.002f;
            float x = inBuf_[i];
            float y = std::clamp(-x * curGain_, -0.95f, 0.95f);
            for (int c = 0; c < ch; c++) out[i * ch + c] = y;

            inPeak = std::max(inPeak, std::fabs(x));
            outPeak = std::max(outPeak, std::fabs(y));

            if (std::fabs(x) > 0.9f) {
                if (++hot_ > 2400) tripped_.store(true);
            } else {
                hot_ = 0;
            }
        }

        if (inPeak > inPeak_.load()) inPeak_.store(inPeak);
        if (outPeak > outPeak_.load()) outPeak_.store(outPeak);
        return oboe::DataCallbackResult::Continue;
    }

private:
    void stopLocked() {
        if (out_) {
            out_->requestStop();
            out_->close();
            out_.reset();
        }
        if (in_) {
            in_->requestStop();
            in_->close();
            in_.reset();
        }
    }

    static constexpr int32_t kMaxFrames = 4096;
    std::shared_ptr<oboe::AudioStream> in_;
    std::shared_ptr<oboe::AudioStream> out_;
    std::mutex mutex_;
    std::atomic<float> targetGain_{0.2f};
    std::atomic<float> inPeak_{0.0f};
    std::atomic<float> outPeak_{0.0f};
    std::atomic<bool> tripped_{false};
    float curGain_ = 0.0f;
    int hot_ = 0;
    std::vector<float> inBuf_;
    std::vector<float> scratch_;
};

static Engine gEngine;

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_example_noisecancel_MainActivity_nativeStart(JNIEnv *, jobject, jint inId, jint outId) {
    return gEngine.start(inId, outId);
}

JNIEXPORT void JNICALL
Java_com_example_noisecancel_MainActivity_nativeStop(JNIEnv *, jobject) {
    gEngine.stop();
}

JNIEXPORT void JNICALL
Java_com_example_noisecancel_MainActivity_nativeSetGain(JNIEnv *, jobject, jfloat gain) {
    gEngine.setGain(gain);
}

JNIEXPORT jfloat JNICALL
Java_com_example_noisecancel_MainActivity_nativeGetLatencyMs(JNIEnv *, jobject) {
    return gEngine.latencyMs();
}

JNIEXPORT jfloat JNICALL
Java_com_example_noisecancel_MainActivity_nativeGetInLevel(JNIEnv *, jobject) {
    return gEngine.takeInPeak();
}

JNIEXPORT jfloat JNICALL
Java_com_example_noisecancel_MainActivity_nativeGetOutLevel(JNIEnv *, jobject) {
    return gEngine.takeOutPeak();
}

JNIEXPORT jboolean JNICALL
Java_com_example_noisecancel_MainActivity_nativeIsTripped(JNIEnv *, jobject) {
    return gEngine.isTripped();
}

}  // extern "C"
