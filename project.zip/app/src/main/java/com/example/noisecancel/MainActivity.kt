package com.example.noisecancel

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        init {
            System.loadLibrary("native-lib")
        }
    }

    external fun nativeStart(inId: Int, outId: Int): Boolean
    external fun nativeStop()
    external fun nativeSetGain(gain: Float)
    external fun nativeGetLatencyMs(): Float
    external fun nativeGetInLevel(): Float
    external fun nativeGetOutLevel(): Float
    external fun nativeIsTripped(): Boolean

    private lateinit var audioManager: AudioManager
    private lateinit var status: TextView
    private lateinit var toggleBtn: Button
    private lateinit var gainLabel: TextView
    private lateinit var gainBar: SeekBar
    private lateinit var latencyText: TextView
    private lateinit var inBar: ProgressBar
    private lateinit var outBar: ProgressBar

    private val handler = Handler(Looper.getMainLooper())
    private var running = false

    private val okTypes = setOf(
        AudioDeviceInfo.TYPE_USB_HEADSET,
        AudioDeviceInfo.TYPE_USB_DEVICE,
        AudioDeviceInfo.TYPE_WIRED_HEADSET
    )

    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            if (nativeIsTripped()) {
                stopNc()
                Toast.makeText(
                    this@MainActivity,
                    "ハウリングの可能性があるためOFFにしました",
                    Toast.LENGTH_LONG
                ).show()
                return
            }
            inBar.progress = (nativeGetInLevel() * 100).toInt()
            outBar.progress = (nativeGetOutLevel() * 100).toInt()
            val l = nativeGetLatencyMs()
            latencyText.text = if (l < 0) "遅延: 測定中..." else "遅延: %.1f ms".format(l)
            handler.postDelayed(this, 100)
        }
    }

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
            refreshStatus()
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
            refreshStatus()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        status = findViewById(R.id.status)
        toggleBtn = findViewById(R.id.toggleBtn)
        gainLabel = findViewById(R.id.gainLabel)
        gainBar = findViewById(R.id.gainBar)
        latencyText = findViewById(R.id.latency)
        inBar = findViewById(R.id.inBar)
        outBar = findViewById(R.id.outBar)

        nativeSetGain(gainBar.progress / 100f)
        gainLabel.text = "強さ: ${gainBar.progress}%"

        gainBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                gainLabel.text = "強さ: $p%"
                nativeSetGain(p / 100f)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        toggleBtn.setOnClickListener {
            if (running) stopNc() else startNc()
        }

        audioManager.registerAudioDeviceCallback(deviceCallback, handler)
        refreshStatus()
    }

    private fun findDevice(flag: Int): AudioDeviceInfo? =
        audioManager.getDevices(flag).firstOrNull { it.type in okTypes }

    private fun refreshStatus() {
        val connected = findDevice(AudioManager.GET_DEVICES_INPUTS) != null &&
                findDevice(AudioManager.GET_DEVICES_OUTPUTS) != null
        status.text = if (connected) "有線イヤホン: 接続中" else "有線イヤホン: 未接続"
        if (!connected && running) stopNc()
        toggleBtn.isEnabled = connected
    }

    private fun startNc() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        val inDev = findDevice(AudioManager.GET_DEVICES_INPUTS)
        val outDev = findDevice(AudioManager.GET_DEVICES_OUTPUTS)
        if (inDev == null || outDev == null) {
            refreshStatus()
            return
        }
        nativeSetGain(gainBar.progress / 100f)
        if (nativeStart(inDev.id, outDev.id)) {
            running = true
            toggleBtn.text = "ON"
            handler.post(ticker)
        } else {
            Toast.makeText(this, "開始できませんでした", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopNc() {
        running = false
        handler.removeCallbacks(ticker)
        nativeStop()
        toggleBtn.text = "OFF"
        inBar.progress = 0
        outBar.progress = 0
        latencyText.text = "遅延: -"
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            startNc()
        }
    }

    override fun onStop() {
        super.onStop()
        if (running) stopNc()
    }

    override fun onDestroy() {
        audioManager.unregisterAudioDeviceCallback(deviceCallback)
        if (running) stopNc()
        super.onDestroy()
    }
}
